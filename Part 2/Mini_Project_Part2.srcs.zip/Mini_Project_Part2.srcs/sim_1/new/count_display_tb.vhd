library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity count_display_tb is
--  Port ( );
end count_display_tb;

architecture Behavioral of count_display_tb is

    constant clk_period : time := 10 ns;
    signal clock : std_logic := '0';
    signal reset : std_logic := '0';
    signal button : std_logic := '0';
    signal leds : std_logic_vector(3 downto 0);
    signal sevenseg : std_logic_vector(6 downto 0);
    signal anode : std_logic_vector(3 downto 0);

begin
    -- Instantiate the Unit Under Test (UUT)
    UUT: entity work.count_display
        port map (
            clock => clock,
            reset => reset,
            button => button,
            leds => leds,
            sevenseg => sevenseg,
            anode => anode
        );

    -- Clock generation process (100 MHz)
    clk_proc: process
    begin
        while true loop
            clock <= '0';
            wait for clk_period/2;
            clock <= '1';
            wait for clk_period/2;
        end loop;
    end process;

    stim_proc: process
    begin
        -- Initial reset
            reset <= '1'; 
            button <= '0'; 
            wait for 30 ns; 
            reset <= '0'; -- Allow debounce circuit to settle wait for 1 ms;

         -- Press #1 -- Hold for more than 20 ms
            button <= '1'; 
            wait for 25 ms; -- Release button 
            button <= '0'; 
            wait for 25 ms;
            
         -- Press #2  
            button <= '1'; 
            wait for 25 ms; 
            button <= '0'; 
            wait for 25 ms; 
            
         -- Press #3 
            button <= '1'; 
            wait for 25 ms; 
            button <= '0'; 
            wait for 25 ms; 
            
         -- Hold button down -- Counter should increment ONLY ONCE 
            button <= '1'; 
            wait for 100 ms; -- Release 
            button <= '0'; 
            wait for 25 ms; 
            
          -- Press several more times 
             button <= '1'; 
             wait for 25 ms; 
             button <= '0'; 
             wait for 25 ms; 
             button <= '1'; 
             wait for 25 ms; 
             button <= '0'; 
             wait for 25 ms; 
             
          -- Test reset 
             reset <= '1'; 
             wait for 30 ns; 
             reset <= '0'; 
             wait for 25 ms;

        -- Stop simulation
        wait;
    end process;

end Behavioral;
