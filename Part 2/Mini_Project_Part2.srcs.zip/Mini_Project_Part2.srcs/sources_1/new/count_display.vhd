library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


entity count_display is
    Port ( clock : in STD_LOGIC;
           reset : in STD_LOGIC;
           button : in STD_LOGIC; -- increment button
           leds : out STD_LOGIC_VECTOR (3 downto 0);
           sevenseg : out STD_LOGIC_VECTOR (6 downto 0);
           anode: out STD_LOGIC_VECTOR (3 downto 0));
end count_display;

architecture Behavioral of count_display is
 signal count_sig: STD_LOGIC_VECTOR (3 downto 0) := "0000";
 signal button_debounce: STD_LOGIC := '0';
begin
    --complete the architecture
    -- instantiate and port map the three components - clk_div, modMcounter and hex_7seg modules
    --refer to the block diagram in lab handout
    -- use the signals declared above in this architecture to wire between components (internally)
    --dont forget to include the generic map in addition to port map
----------------------------------------
     -- Button Debouncer
    debounce1: entity work.button_debounce 
        generic map ( 
            STABLE_CYCLES => 2_000_000
            )
        port map (
            clk_in => clock, 
            reset => reset, 
            btn_in => button, 
            btn_db => button_debounce 
        );
----------------------------------------
    --Mod M Counter
    counter1: entity work.modMCounter
        generic map (N => 4)  -- 4-bit counter (0-15)
        port map (
            clk => button_debounce,
            reset => reset,
            count => count_sig
        );
----------------------------------------
    --Seven Segment
    display1: entity work.hex_7seg
        port map (
            hexdigit => count_sig,
            seg      => sevenseg
        );
----------------------------------------
    leds  <= count_sig;
    anode <= "1110";  -- enable rightmost digit only (active low)

end Behavioral;
