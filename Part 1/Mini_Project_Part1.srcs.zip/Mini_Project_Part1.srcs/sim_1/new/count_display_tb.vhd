library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity count_display_tb is
--  Port ( );
end count_display_tb;

architecture Behavioral of count_display_tb is

    constant clk_period : time := 10 ns;
    signal clock : std_logic := '0';
    signal reset : std_logic := '0';
    signal leds : std_logic_vector(3 downto 0);
    signal sevenseg : std_logic_vector(6 downto 0);
    signal anode : std_logic_vector(3 downto 0);

begin
    -- Instantiate the Unit Under Test (UUT)
    UUT: entity work.count_display
        port map (
            clock => clock,
            reset => reset,
            leds => leds,
            sevenseg => sevenseg,
            anode => anode
        );

    -- Clock generation process (100 MHz)
    clk_proc: process
    begin
        while true loop
            clock <= '0';
            wait for clk_period/2;
            clock <= '1';
            wait for clk_period/2;
        end loop;
    end process;

    stim_proc: process
    begin
        -- Initial reset
        reset <= '1';
        wait for 2*clk_period;
        reset <= '0';

        -- Let the simulation run for several seconds to see counting
        wait for 20 ms;  -- enough to see the counter go 0 to F slowly

        -- Stop simulation
        wait;
    end process;

end Behavioral;
